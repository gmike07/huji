package processing.searchStrategies;

import processing.textStructure.Word;
import processing.textStructure.WordResult;

import java.util.HashMap;
import java.util.List;

public class DictionarySearch implements IsearchStrategy {

	public DictionarySearch(HashMap<Integer, List<Word>> dict) {

	}

	@Override
	public List<? extends WordResult> search(String query) {
	
	}
	

}
