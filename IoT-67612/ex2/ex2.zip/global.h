#ifndef GLOBAL_H
#define GLOBAL_H

#define FAILURE_CODE -1
#define SUCCESS_CODE 0

#endif //GLOBAL_H
