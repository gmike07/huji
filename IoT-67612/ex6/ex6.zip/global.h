#ifndef GLOBAL_H
#define GLOBAL_H

#define FAILURE_CODE -1
#define SUCCESS_CODE 0

#define TRUE 1
#define FALSE 0

#endif //GLOBAL_H
