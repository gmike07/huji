#ifndef EX4_TEST_CELLULAR_H
#define EX4_TEST_CELLULAR_H

int SendCmdRecvResp_TestCops_1(unsigned char *cmd, unsigned char *resp_buf, unsigned int resp_max_size, unsigned int timeout_ms);

int SendCmdRecvResp_TestCops_2(unsigned char *cmd, unsigned char *resp_buf, unsigned int resp_max_size, unsigned int timeout_ms);

int SendCmdRecvResp_TestCops_3(unsigned char *cmd, unsigned char *resp_buf, unsigned int resp_max_size, unsigned int timeout_ms);

#endif //EX4_TEST_CELLULAR_H
