#ifndef EX4_UTILS_H
#define EX4_UTILS_H

int isnumber(unsigned char *candidate, int len);

#endif //EX4_UTILS_H
