import game

game.main()